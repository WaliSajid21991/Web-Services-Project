package com.banksystem.BankSystem.bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;


public class DatabaseClass {

	private static Map<Long, Customer> messages = new HashMap<>();
	private static Map<Long, Account> profiles = new HashMap<>();
	private static Map<Long, Transaction> transaction = new HashMap<>();

	
	public static Map<Long, Customer> getCustomers() {
//		
//		try{
//			Connection con = db.createConnection();
//			Statement st = con.createStatement();
//			ResultSet rs = st.executeQuery("select * from customer");
//			while(rs.next()){

//			}
//			con.close();
//			
//		}catch(Exception e){
//			e.printStackTrace();
//		}
		return messages;
	}


	
	
	public static Map<Long, Account> getAccounts() {
		return profiles;
	}
	
	public static Map<Long, Transaction> getTransactions() {
		return transaction;
	}

//	public static Map<Long, Account> getAccountsCust(long id) {
//		Map<Long, Account> account = new HashMap<>();
//		while (profiles.values().iterator().hasNext())
//		{
//			
//		}
//		return profiles;
//	}
	
	
}
