package com.banksystem.BankSystem.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Transaction {
	

	private int Amount;
	private long Accountid;
	private String TransType;
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(long accountId2,int Amount,String string) {
		// TODO Auto-generated constructor stub
		this.Accountid=accountId2;
		this.Amount=Amount;
		this.TransType=string;
	}

	/**
	 * @return the transactionid
	 */
//	public int getTransactionid() {
//		return Transactionid;
//	}
//
//	/**
//	 * @param transactionid the transactionid to set
//	 */
//	public void setTransactionid(int transactionid) {
//		Transactionid = transactionid;
//	}

	/**
	 * @return the amount
	 */
	public int getAmount() {
		return Amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(int amount) {
		Amount = amount;
	}
	public String getTransType() {
		return TransType;
	}

	public void setTransType(String transType) {
		TransType = transType;
	}

	/**
	 * @return the accountid
	 */
	public long getAccountid() {
		return Accountid;
	}

	/**
	 * @param accountid the accountid to set
	 */
	public void setAccountid(int accountid) {
		Accountid = accountid;
	}

	/**
	 * @return the transDate
	 */
//	public Date getTransDate() {
//		return TransDate;
//	}
//
//	/**
//	 * @param transDate the transDate to set
//	 */
//	public void setTransDate(Date transDate) {
//		TransDate = transDate;
//	}


}
