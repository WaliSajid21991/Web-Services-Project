package com.banksystem.BankSystem.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import org.koushik.javabrains.messenger.database.DatabaseClass;
public class TransactionService {

	private Map<Long, Transaction> trans = DatabaseClass.getTransactions();
	
	public TransactionService() {
		trans.put(1L, new Transaction(1L, 1000, "Lodgement"));
	}
	
	public List<Transaction> getAllTransactions() {
		//Map<Long, Account> acc
		return new ArrayList<Transaction>(trans.values()); 
	}

	
}