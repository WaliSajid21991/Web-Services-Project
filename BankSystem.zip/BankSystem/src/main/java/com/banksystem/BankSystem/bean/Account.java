package com.banksystem.BankSystem.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Account extends Customer{
	
	private int Accountid;
	private int Balance;
	

	public Account() {
		// TODO Auto-generated constructor stub
		
		
	}

	/**
	 * @return the id
	 */
	

	public Account(int id, int Balance) {
		// TODO Auto-generated constructor stub
		this.Accountid=id;
		this.Balance=Balance;
		
	}

	public Account(int id, int Balance, long custid) {
		// TODO Auto-generated constructor stub
		this.Accountid=id;
		this.Balance=Balance;
		super.id= custid;
	}

	
	/**
	 * @return the accountid
	 */
	public int getAccountid() {
		return Accountid;
	}

	/**
	 * @param accountid the accountid to set
	 */
	public void setAccountid(int accountid) {
		Accountid = accountid;
	}
	
	

	/**
	 * @return the name
	 */
//	public String getName() {
//		return name;
//	}

	/**
	 * @param name the name to set
	 */
//	public void setName(String name) {
//		this.name = name;
//	}

	/**
	 * @return the addresses
	 */
//	public String getAddresses() {
//		return addresses;
//	}

	/**
	 * @param addresses the addresses to set
	 */
//	public void setAddresses(String addresses) {
//		this.addresses = addresses;
//	}

	public int getBalance() {
		return Balance;
	}

	public void setBalance(int balance) {
		Balance = balance;
	}

//	public void setId(int i) {
//		// TODO Auto-generated method stub
//		
//	}

}
