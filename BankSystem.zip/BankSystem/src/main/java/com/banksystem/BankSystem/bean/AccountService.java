package com.banksystem.BankSystem.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import org.koushik.javabrains.messenger.database.DatabaseClass;
public class AccountService {

	private Map<Long, Account> acc = DatabaseClass.getAccounts();
	private Map<Long, Transaction> trans = DatabaseClass.getTransactions();
	
	public AccountService() {
		acc.put(1L, new Account(1,1000));
		acc.put(2L, new Account(2,2000));
		acc.put(3L, new Account(2,2000,1));
		trans.put(1L, new Transaction(1L, 1000, "Lodgement"));
	}
	
	public List<Transaction> getAllTransactions() {
		//Map<Long, Account> acc
		return new ArrayList<Transaction>(trans.values()); 
	}

	public List<Account> getAllAccounts() {
		//Map<Long, Account> acc
		return new ArrayList<Account>(acc.values()); 
	}
	
	public List<Account> getAccountidbyCust(long id)
	{
		ArrayList<Account> accountbycust = new ArrayList<Account>();
		for (long key : acc.keySet()) {
//			   System.out.println("------------------------------------------------");
//			   System.out.println("Iterating or looping map using java5 foreach loop");
//			   System.out.println("key: " + key + " value: " + loans.get(key));
			if(( acc.get(key).equals(id)))
					{
					accountbycust.add(accountbycust.size()+1, (Account)(acc.get(key)));
			}
		}
		return accountbycust;
	}
	
	public Account getAccount(long id) {
		return acc.get(id);
	}


	public boolean getAccountLodge(long accountId, int amount) {
		// TODO Auto-generated method stub
		
		int balance=acc.get(accountId).getBalance();
		balance=balance+amount;
		acc.get(accountId).setBalance(balance);
		System.out.println("balance"+acc.get(accountId).getBalance());
		trans.put(1L, new Transaction(accountId,amount,"lodge"));
		return true;
	}
	

	public boolean getAccountWithdraw(long accountId, int amount) {
		// TODO Auto-generated method stub
		
		int balance=acc.get(accountId).getBalance();
		balance-=amount;
		if(balance>0)
		{
		acc.get(accountId).setBalance(balance);
		trans.put(2L, new Transaction(accountId,amount,"withdraw"));
		return true;
		}
		else 
			return false;
	}
	
//	public Customer addCustomer(Customer cust) {
//		 cust.setId(customer.size() + 1);
//		customer.put(cust.getId(), cust);
//		return cust;
//	}


//	public List<Account> getAllAccounts() {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
//	public Customer updateMessage(Customer cust) {
//		if (cust.getId() <= 0) {
//			return null;
//		}
//		customer.put((long) ((Customer) customer).getId(), cust);
//		return cust;
//	}
//	
//	public Customer removeMessage(long id) {
//		return customer.remove(id);
//	}

	
}
