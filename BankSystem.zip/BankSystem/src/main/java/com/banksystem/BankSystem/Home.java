package com.banksystem.BankSystem;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/home")
public class Home {

//	 @GET
//	  @Produces(MediaType.TEXT_PLAIN)
//	  public String sayPlainTextHome() {
//	    return "Welcome to AIB BANK Home Page";
//	  }

	  // This method is called if XML is request
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public String sayXMLHome() {
	    return "<?xml version=\"1.0\"?>" + "<hello> Welcome to AIB BANK Home Page" + "</hello>";
	  }

	  // This method is called if HTML is request
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	  public String getHTMLOnlineInfo() {
	    return "<html> " + "<title>" + "AIB Bank" + "</title>"
	        + "<body><h1>" + "Welcome to AIB BANK</h1>" +"<br><br>Username</h4> <input type="+"text"+"></input>"+ 
	    	"<br>Password</h4>"+" <input type="+"password"+"></input>"+ "<br><button type="+"button"+">Login</button></body>"
	        +"<a href="+"/webapi/home/lodgement"+">Lodgement</a>"+ "</html> ";
	  }
	  @Path("/lodgement")
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	  public String getHTMLLodge() {
//	    return "<html> " + "<title>" + "AIB Bank" + "</title>"
//	        + "<body><h4>" + "Enter Amount to Lodge into your account</h4> <input type="+"text"+"></input>" + "<br><button type="+"button"+">Lodge</button>"
//	    	+	"</body></h1>" + "</html> ";
	    return "<html><body><form onsubmit="+"myFunction()"+">"+
  "Enter Amount: <input type="+"text"+ "name="+"amount"+"></input>"+
  "<br><button type="+"button"+">Lodge</button>"+
 "</form>"+"<script>function myFunction() {"+
    "open.url("+"http://localhost:8080/webapi/accounts/1/lodgement/100"+");"+"}</script></body></html>";
	     
	  }
	  
	  @Path("/transfer")
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	  public String getHTMLTransfer() {
	    return "<html> " + "<title>" + "AIB Bank" + "</title>"
	        + "<body><h4>" + "Enter the Account number <input type="+"text"+"></input>" +  "<br>Enter Amount to Lodge into your account</h4> <input type="+"text"+"></input><br><button type="+"button"+">Transfer</button>"
	    	+	"</body></h1>" + "</html> ";
	  }
	  @PUT
	  @Path("{CustomerId}")
	  @Produces(MediaType.TEXT_PLAIN)
	  public String updateCustomerInfo(@PathParam("CustomerId") String CustomerId)
	  {
		  //Code to update customer record using customerid
		  return "Done Successfully";
	  }
	  
//	  @POST
//      @Produces(MediaType.TEXT_HTML)
//      @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//      public void newTodo(@FormParam("id") String id,
//                      @FormParam("summary") String summary,
//                      @FormParam("description") String description,
//                      @Context HttpServletResponse servletResponse) throws IOException {
//              Customer cust = new Customer("123","123");
//              Transactions trans= new Transactions();
//              trans.setTransType("lodge");
//              }
//              //TodoDao.instance.getModel().put(id, todo);
//
//              servletResponse.sendRedirect("../Lodged.html");
//      }


}
