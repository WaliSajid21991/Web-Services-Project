
//JPA connectivity done using Book Lab
package com.banksystem.BankSystem.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

//import 
//import org.koushik.javabrains.messenger.database.DatabaseClass;
public class CustomerService {

	private Map<Long, Customer> customer = DatabaseClass.getCustomers();
        
         private EntityManagerFactory emf = Persistence.createEntityManagerFactory("Customer");
    private EntityManager em = emf.createEntityManager();
    private EntityTransaction tx = em.getTransaction();  
	
	public CustomerService() {
//		customer.put(1L, new Customer(1, "Waleed Sajid", "Dublin","11"));
//		customer.put(2L, new Customer(2, "Leonardo", "US","22"));
	}
	
	
	public List<Customer> getAllMessages() {
		return allEntries();
	}
	public List<Customer> allEntries() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Customer> cq = cb.createQuery(Customer.class);
        Root<Customer> rootEntry = cq.from(Customer.class);
        CriteriaQuery<Customer> all = cq.select(rootEntry);
        TypedQuery<Customer> allQuery = em.createQuery(all);
        return allQuery.getResultList();
    }
	public Customer getCustomer(long id) {
		Customer test = em.find(Customer.class, id);
        em.close();
        return test;
	}
//	 public Customer retrieveBook(int id) {
//        Book test = em.find(Book.class, id);
//        em.close();
//        return test;
//    }
//	public Customer addCustomer(Customer cust) {
//		 cust.setId(customer.size() + 1);
//		customer.put(cust.getId(), cust);
//		return cust;
//	}
         public Customer createCustomer(Customer b) {
              System.out.println("inCreateCustomer");
         Customer test = em.find(Customer.class, b.getId());
         System.out.println("inCreateCustomer");
        if (test == null) {
            tx.begin();
            em.persist(b);
            tx.commit();
            
            em.close();
        }
          return b;
         }
         
          public void deleteCustomer(int id) {
        Customer test = em.find(Customer.class, id);
        if (test !=null) {
            tx.begin();
            em.remove(test);
            tx.commit();
            
            em.close();
        }
    }
}

//	public List<Account> getAllAccounts() {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
//	public Customer updateMessage(Customer cust) {
//		if (cust.getId() <= 0) {
//			return null;
//		}
//		customer.put((long) ((Customer) customer).getId(), cust);
//		return cust;
//	}
//	
//	public Customer removeMessage(long id) {
//		return customer.remove(id);
//	}

	

