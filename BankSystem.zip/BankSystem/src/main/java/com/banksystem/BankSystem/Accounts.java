package com.banksystem.BankSystem;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.banksystem.BankSystem.bean.Account;
import com.banksystem.BankSystem.bean.AccountService;
import com.banksystem.BankSystem.bean.Customer;
import com.banksystem.BankSystem.bean.CustomerService;
import com.banksystem.BankSystem.bean.Transaction;

@Path("/accounts")
public class Accounts {


	AccountService customerservice= new AccountService();
	  // This method is called if XML is request
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public List<Account> getAccount() {
	    return customerservice.getAllAccounts();
	  }

	  @GET
	  @Path("{AccountId}")
	  @Produces(MediaType.TEXT_XML)
	  public Customer updateCustomerInfo(@PathParam("AccountId") long AccountId)
	  {
		  //Code to update customer record using customerid
		  return customerservice.getAccount(AccountId);
	  }
	  
	  @PUT
	  @Path("{AccountId}/lodgment/{amount}")
	  @Produces(MediaType.TEXT_XML)
	  public String updateCustomerLodgeInfo(@PathParam("AccountId") long AccountId,@PathParam("amount") int amount)
	  {
		  //Code to update customer record using customerid
		   if(customerservice.getAccountLodge(AccountId,amount))
		   {
			   return "Lodged"+amount+"Successfully";
		   }
		   return "Failed to Lodge the amount";
	  }		    
	  
		@PUT
		@Path("{AccountId}/withdraw/{amount}")
		@Produces(MediaType.TEXT_XML)
		public String updateCustomerWithdrawInfo(@PathParam("AccountId") long AccountId,@PathParam("amount") int amount)
		{
			//Code to update customer record using customerid
			if(customerservice.getAccountWithdraw(AccountId,amount))
			{
				return "Withdaw"+amount+"Successfully";
			}
			return "Failed to Withdraw the amount. Check the balance";
		}
		
		 		 
//		  @GET
//		  @Path("/transactions")
//		  @Produces(MediaType.TEXT_XML)
//		  public List<Transactions> getTransactions() {
//		    return customerservice.getAllTransactions();
//		  }

}
	  // This method is called if HTML is request
	  
//	  @GET
//	  @Path("{CustomerId}")
//	  @Produces(MediaType.TEXT_XML)
//	  public Customer updateCustomerInfo(@PathParam("CustomerId") long CustomerId)
//	  {
//		  //Code to update customer record using customerid
//		  return customerservice.getCustomer(CustomerId);
//	  }
//	  
	  
//	  @POST
//	  @Consumes(MediaType.APPLICATION_JSON)
//	  @Produces(MediaType.APPLICATION_JSON)
//	  public String postCustomer(Customer cust)
//	  {
//		  //Code to update customer record using customerid
//		  customerservice.addCustomer(cust);
//		  return "Psot works fine";
//	  }
//	  @GET
//	  @Path("/account")
//	  @Produces(MediaType.TEXT_XML)
//	  public List<Account> getAccounts() {
//		  AccountService accountservice= new AccountService();
//		    return accountservice.getAllAccounts();
//		  }



